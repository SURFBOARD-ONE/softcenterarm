#!/bin/sh

rm -rf /jffs/softcenter/bin/BaiduPCS
rm -rf /jffs/softcenter/bin/pcs_config.json
rm -rf /jffs/softcenter/scripts/baidupcs_config.sh
rm -rf /jffs/softcenter/webs/Module_baidupcs.asp
rm -rf /jffs/softcenter/res/icon-baidupcs.png
rm -rf /jffs/softcenter/init.d/*baidupcs.sh
rm -rf /jffs/softcenter/scripts/baidupcs_uninstall.sh

